// Sample activity data
const activityData = [
    { id: 1, text: 'JOINED THE SPOTIFY', date: '2024-12-01' },
    { id: 2, text: 'JOINED THE INSTAGRAM ', date: '2024-12-02' },
    { id: 3, text: 'JOINED THE TELEGRAM.', date: '2024-12-03' },
];

// Function to load more activities
function loadActivity() {
    const activityFeed = document.getElementById('activity-feed');

    activityData.forEach((activity) => {
        const activityElement = document.createElement('div');
        activityElement.classList.add('activity-item');
        activityElement.innerHTML = `
            <p><strong>Activity:</strong> ${activity.text}</p>
            <p><strong>Date:</strong> ${activity.date}</p>
        `;
        activityFeed.appendChild(activityElement);
    });
}

// Function to handle password update
function updatePassword() {
    const password = document.getElementById('change-password').value;
    if (password) {
        alert('Password has been updated.');
    } else {
        alert('Please enter a valid password.');
    }
}

// Load initial activities on page load
document.addEventListener('DOMContentLoaded', function() {
    loadActivity();
});
