document.getElementById('autofill-btn').addEventListener('click', () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: () => {
              // Find the email input field
              const emailField = document.querySelector(
                  'input[type="email"], input[name="email"], input[id="email"]'
              );

              // Autofill if the field is found
              if (emailField) {
                  const url = "https://api.guerrillamail.com/ajax.php";
                  const params = new URLSearchParams({
                      f: 'get_email_address',
                      ip: '127.0.0.1', // Replace with your IP address
                      agent: 'Mozilla_foo_bar' // Replace with your user-agent string
                  });

                  const cookies = 'PHPSESSID=873rkpb0h8oe0hnsfg229nvhvr'; // Replace with actual PHPSESSID

                  // Fetch the email address
                  fetch(`${url}?${params.toString()}`, {
                      method: 'GET',
                      headers: {
                          'Cookie': cookies
                      }
                  })
                      .then(response => {
                          if (!response.ok) {
                              throw new Error(`HTTP error! Status: ${response.status}`);
                          }
                          return response.json();
                      })
                      .then(data => {
                          // Check if the email address is present in the response
                          const email = data.email_addr || "example@example.com"; // Fallback to default email
                          
                          // Autofill and make the value persistent
                          emailField.value = email;

                          // Trigger an input event to ensure the value is saved
                          const inputEvent = new Event('input', { bubbles: true });
                          emailField.dispatchEvent(inputEvent);

                          // Log success
                          console.log('Email autofilled with:', email);
                      })
                      .catch(error => {
                          console.error('Error fetching email address:', error);
                      });
              } else {
                  console.warn('No email input field found on this page.');
              }
          },
      });
  });
});
